<?php

/*------------------------------------------------------------------
// Add Thumbnails in Manage Posts/Pages List
-------------------------------------------------------------------*/
if ( !function_exists('AddThumbColumn') && function_exists('add_theme_support') ) {

    // for post and page
    add_theme_support('post-thumbnails', array( 'post', 'page' ) );

    function AddThumbColumn($cols) {
        $cols['thumbnail'] = __('Thumbnail');
        return $cols;
    }

    function AddThumbValue($column_name, $post_id) {

            $width = (int) 35;
            $height = (int) 35;

            if ( 'thumbnail' == $column_name ) {
                // thumbnail of WP 2.9
                $thumbnail_id = get_post_meta( $post_id, '_thumbnail_id', true );
                // image from gallery
                $attachments = get_children( array('post_parent' => $post_id, 'post_type' => 'attachment', 'post_mime_type' => 'image') );
                if ($thumbnail_id)
                    $thumb = wp_get_attachment_image( $thumbnail_id, array($width, $height), true );
                elseif ($attachments) {
                    foreach ( $attachments as $attachment_id => $attachment ) {
                        $thumb = wp_get_attachment_image( $attachment_id, array($width, $height), true );
                    }
                }
                    if ( isset($thumb) && $thumb ) {
                        echo $thumb;
                    } else {
                        echo __('None');
                    }
            }
    }
}
    // for posts
    add_filter( 'manage_posts_columns', 'AddThumbColumn' );
    add_action( 'manage_posts_custom_column', 'AddThumbValue', 10, 2 );

    // for pages
    add_filter( 'manage_pages_columns', 'AddThumbColumn' );
    add_action( 'manage_pages_custom_column', 'AddThumbValue', 10, 2 );

/*------------------------------------------------------------------
// add google analytics to footer
-------------------------------------------------------------------*/
// function add_google_analytics() {
//  echo '<script src="http://www.google-analytics.com/ga.js" type="text/javascript"></script>';
//  echo '<script type="text/javascript">';
//  echo 'var pageTracker = _gat._getTracker("UA-XXXXX-X");';
//  echo 'pageTracker._trackPageview();';
//  echo '</script>';
// }
// add_action('wp_footer', 'add_google_analytics');

/*------------------------------------------------------------------
// Check if Remote File Exists in URL
-------------------------------------------------------------------*/
function file_exists_remote($url) {
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_NOBODY, true);
    
    $result = curl_exec($curl); // Check connection only
    $ret = false; // Actual request

    if ($result !== false) {
        $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        
        if ($statusCode == 200) { // Check HTTP status code
            $ret = true;  
        }
    }
    curl_close($curl);
    return $ret;
}

/*------------------------------------------------------------------
// detect if current page is the login page
-------------------------------------------------------------------*/
function is_login_page() {
    return !strncmp($_SERVER['REQUEST_URI'], '/wp-login.php', strlen('/wp-login.php'));
}

/*------------------------------------------------------------------
// Load jQuery from the CDN Library with fallback option
-------------------------------------------------------------------*/
// function load_external_jQuery() {
//     $host = $_SERVER['SERVER_NAME'];
//     if(strpos($_SERVER['SERVER_NAME'], 'local') === false) {
//         if (!is_admin() && !is_login_page()) {
//             wp_deregister_script( 'jquery-core' ); // deregisters the default WordPress jQuery core
//             wp_deregister_script( 'jquery-migrate' ); // deregisters the default WordPress jQuery migrate

//             $url = 'http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'; // the URL jQuery core
//             $urls = 'http://code.jquery.com/jquery-migrate-1.2.1.min.js'; // the URL jQuery migrate
//             $exist = file_exists_remote($url); // test parameters 
//             $exists = file_exists_remote($urls); // test parameters 
            
//             if( $exist && $exists ) { // test if the URL exists then register the CDN file  
//                 wp_register_script('jquery-core', 'http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js', false, '1.10.2');
//                 wp_register_script('jquery-migrate', 'http://code.jquery.com/jquery-migrate-1.2.1.min.js', false, '1.2.1');
//             }
//             else{// register the local file 
//                 wp_register_script('jquery-core', '/wp-includes/js/jquery/jquery.js', false, '1.10.2'); 
//                 wp_register_script('jquery-migrate', '/wp-includes/js/jquery/jquery-migrate.min.js', false, '1.2.1');
//             }
//             wp_enqueue_script('jquery-core'); // enqueue the jquery core 
//             wp_enqueue_script('jquery-migrate'); // enqueue the jquery migrate 
//         }
//     }
// }
// add_action('init', 'load_external_jQuery');

/*------------------------------------------------------------------
// Add Custom Post Types to Tags and Categories in WordPress
-------------------------------------------------------------------*/

function add_custom_types_to_tax( $query ) {
if( is_category() || is_tag() && empty( $query->query_vars['suppress_filters'] ) ) {

// Get all your post types
$post_types = get_post_types();

$query->set( 'post_type', $post_types );
return $query;
}
}
add_filter( 'pre_get_posts', 'add_custom_types_to_tax' );


?>
