<?php

/*------------------------------------------------------------------
// add shortcode for homepage url
-------------------------------------------------------------------*/
add_shortcode('HOME', 'mysiteurl');
function mysiteurl() {
    return get_bloginfo('url');
}
add_shortcode('TEMPLATE', 'dasadda');
function dasadda() {
    return body_class();
}

/*------------------------------------------------------------------
// add shortcode for CDN url for direct placement
-------------------------------------------------------------------*/
add_shortcode('CDN', 'mycdnurl');
function mycdnurl() {
    return 'http://cdn.' . $_SERVER['HTTP_HOST'] . '/static';
}

/*------------------------------------------------------------------
// add shortcode for text widget
-------------------------------------------------------------------*/
add_filter( 'widget_text', 'do_shortcode');

/*------------------------------------------------------------------
// put a shortcode return to home url in a custom menu link
-------------------------------------------------------------------*/
add_filter('wp_nav_menu', 'menu_shortcodes');
function menu_shortcodes( $menu ){
	return str_replace('_HOME_',preg_replace("~^(?:f|ht)tps?://~i", '', home_url() ), do_shortcode( $menu ) );
}



?>
