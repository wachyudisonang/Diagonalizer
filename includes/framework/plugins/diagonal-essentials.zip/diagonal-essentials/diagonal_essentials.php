<?php
/*
Plugin Name: Diagonal Essentials
Plugin URI: http://www.diagonalnetwork.com/
Description: Common essentials function needs to build new sites project. Diagonal Essentials is the full-meal deal – the entire collection neatly organized into a single chunk of code.
Version: 1.1
Author: Wachyudi Sonang
Author URI: http://sonangsatriani.com
License: A "Slug" license name e.g. GPL2
*/

/*------------------------------------------------------------------
// load setting's link in plugin
-------------------------------------------------------------------*/
function wp_clean_up_settings_link($action_links,$plugin_file){
    if($plugin_file==plugin_basename(__FILE__)){
        $wcu_settings_link = '<a href="options-general.php?page=' . dirname(plugin_basename(__FILE__)) . '/diagonal_essentials_admin.php">' . __("Settings") . '</a>';
        array_unshift($action_links,$wcu_settings_link);
    }
    return $action_links;
}
add_filter('plugin_action_links','wp_clean_up_settings_link',10,2);
if(is_admin()){require_once('diagonal_essentials_admin.php');}

include 'diagonal_shortcode.php';
include 'diagonal_addons.php';

/*------------------------------------------------------------------
// load translations
-------------------------------------------------------------------*/
function load_wp_clean_up_lang(){
    $currentLocale = get_locale();
    if(!empty($currentLocale)){
        $moFile = dirname(__FILE__) . "/lang/diagonal-" . $currentLocale . ".mo";
        if(@file_exists($moFile) && is_readable($moFile)) load_textdomain('Diagonal-Network',$moFile);
    }
}
add_filter('init','load_wp_clean_up_lang');

/*------------------------------------------------------------------
// put admin languange in english
-------------------------------------------------------------------*/
add_action( 'plugins_loaded', 'admin_in_english_add_hooks' );
function admin_in_english_add_hooks() {
    add_filter( 'locale', 'admin_in_english_locale' );
}

function admin_in_english_locale( $locale ) {
    if ( admin_in_english_should_use_english() ) {
        return 'en_US';
    }
    return $locale;
}

function admin_in_english_should_use_english() {
    // frontend AJAX calls are mistakend for admin calls, 
    // because the endpoint is wp-admin/admin-ajax.php
    return admin_in_english_is_admin() && !admin_in_english_is_frontend_ajax();
}

function admin_in_english_is_admin() {
    return
        is_admin() || admin_in_english_is_tiny_mce() || admin_in_english_is_login_page();
}

function admin_in_english_is_frontend_ajax() {
    return defined( 'DOING_AJAX' ) && DOING_AJAX && false === strpos( wp_get_referer(), '/wp-admin/' );
}

function admin_in_english_is_tiny_mce() {
    return false !== strpos( $_SERVER['REQUEST_URI'], '/wp-includes/js/tinymce/');
}

function admin_in_english_is_login_page() {
    // return false !== strpos( $_SERVER['REQUEST_URI'], '/wp-login.php' );
}

/*------------------------------------------------------------------
// Change the default media upload folder
-------------------------------------------------------------------*/
add_action( 'load-options-media.php', 'uupe_init' );
add_action( 'load-options.php', 'uupe_init' );
function uupe_init() {
	if ( !get_option('upload_url_path') && !( get_option('upload_path') != 'wp-content/uploads' && get_option('upload_path') ) ) {
		register_setting( 'media', 'upload_path', 'esc_attr' );
		register_setting( 'media', 'upload_url_path', 'esc_url'  );
		add_settings_field( 'upload_path', __( 'Store uploads in this folder' ), 'uupe_upload_path', 'media',	'uploads', array( 'label_for' => 'upload_path' ) );
		add_settings_field( 'upload_url_path', __( 'Full URL path to files' ), 'uupe_upload_url_path', 'media',	'uploads', array( 'label_for' => 'upload_url_path' ) );
	}
}

function uupe_upload_path( $args ) { ?>
	<input name="upload_path" type="text" id="upload_path" value="<?php echo esc_attr(get_option('upload_path')); ?>" class="regular-text code" />
	<p class="description"><?php _e('Default is <code>img</code>'); ?></p>
	<?php
}

function uupe_upload_url_path( $args ) { ?>
	<input name="upload_url_path" type="text" id="upload_url_path" value="<?php echo esc_attr( get_option('upload_url_path')); ?>" class="regular-text code" />
	<p class="description"><?php _e('Fill with registered subdomain image path like <code>http://img.domain.com</code>, localhost image path like <code>http://domain.com/img</code> or let it blank'); ?></p>
	<?php
}

/*------------------------------------------------------------------
// add a favicon 
-------------------------------------------------------------------*/
function blog_favicon() {
    echo '<link rel="Shortcut Icon" type="image/x-icon" href="'.get_bloginfo('wpurl').'/favicon.ico" />';
}
add_action('wp_head', 'blog_favicon');

/*------------------------------------------------------------------
// Disable Admin Bar
-------------------------------------------------------------------*/
show_admin_bar( false );

/*------------------------------------------------------------------
// remove WordPress outputs version like <meta content="WordPress 3.7.1" name="generator">
-------------------------------------------------------------------*/
remove_action('wp_head', 'wp_generator');

/*------------------------------------------------------------------
// delay feed update before pushing it out to your RSS readers
-------------------------------------------------------------------*/
function publish_later_on_feed($where) {
    global $wpdb;

    if (is_feed()) {
       
        $now = gmdate('Y-m-d H:i:s'); // timestamp in WP-format [DON'T CHANGE]

        $wait = '2'; // value for wait; + device [integer]

        $device = 'DAY'; // MINUTE, HOUR, DAY, WEEK, MONTH, YEAR

        // add SQL-sytax to default $where
        $where .= " AND TIMESTAMPDIFF($device, $wpdb->posts.post_date_gmt, '$now') > $wait ";
    }
    return $where;
}
add_filter('posts_where', 'publish_later_on_feed');

/*------------------------------------------------------------------
// Change the Footer in WordPress Admin Panel
-------------------------------------------------------------------*/
add_filter('admin_footer_text', 'remove_footer_admin');
function remove_footer_admin () {
    echo 'Fueled by <a href="http://www.wordpress.org" target="_blank">WordPress</a> | Designed by <a href="http://diagonalnetwork.com" target="_blank">Diagonal Network</a> | Webmaster: <a href="http://sonangsatriani.com" target="_blank">Sonang Satriani</a></p>';
}

/*------------------------------------------------------------------
// remove unnecessary dashboard widgets
-------------------------------------------------------------------*/
add_action('admin_menu', 'disable_default_dashboard_widgets');  
function disable_default_dashboard_widgets() {
    remove_meta_box('dashboard_recent_comments', 'dashboard', 'core');  
    remove_meta_box('dashboard_quick_press', 'dashboard', 'core');  
    remove_meta_box('dashboard_recent_drafts', 'dashboard', 'core');  
    remove_meta_box('dashboard_plugins', 'dashboard', 'core');  
    remove_meta_box('dashboard_primary', 'dashboard', 'core');  
    remove_meta_box('dashboard_secondary', 'dashboard', 'core');  
}  

function my_login_stylesheet() { ?>
    <link rel="stylesheet" id="custom_wp_admin_css"  href="<?php echo get_bloginfo( 'stylesheet_directory' ) . '/style-login.css'; ?>" type="text/css" media="all" />
<?php }
add_action( 'login_enqueue_scripts', 'my_login_stylesheet' );

/*------------------------------------------------------------------
// add body styles based on browser engine
-------------------------------------------------------------------*/
add_filter('body_class','browser_body_class');
function browser_body_class($classes) {
    global $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone;

        if($is_lynx) $classes[] = 'lynx';
        elseif($is_gecko) $classes[] = 'gecko';
        elseif($is_opera) $classes[] = 'opera';
        elseif($is_NS4) $classes[] = 'ns4';
        elseif($is_safari) $classes[] = 'safari';
        elseif($is_chrome) $classes[] = 'chrome';
        elseif($is_IE) $classes[] = 'ie';
        else $classes[] = 'unknown';

        if($is_iphone) $classes[] = 'iphone';

    return $classes;
}

/*------------------------------------------------------------------
// forbidden register without secret key
-------------------------------------------------------------------*/
// ob_start();
// add_filter( 'site_url', 'change_register_url' );
// function change_register_url( $url ) {
// 	if( strpos($url, '?action=register' ) ) {
// 		$url = get_site_url(1) . '/wp-login.php?rv0a0g16d6ydazaj30lwh&action=register';
// 	}
// 	return $url;
// }

// add_action('login_head', 'forbidden_regular_register_url' );
// function forbidden_regular_register_url( $url ) {
// 	$QS = '?action=register';
// 	$theRequest = site_url('/wp-login.php') . '?'. $_SERVER['QUERY_STRING'];

// 	if ( site_url('/wp-login.php').$QS == $theRequest ) {
// 		wp_safe_redirect( '404.php' );
// 		ob_end_flush();
// 	}

// }


?>
